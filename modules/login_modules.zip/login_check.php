<?php
    session_start();
	
if (isset($_POST['login'])) { $login = $_POST['login']; if ($login == '') { unset($login);} } //получаем и заносим логин в переменную, если пусто уничтожаем
    if (isset($_POST['password'])) { $password=$_POST['password']; if ($password =='') { unset($password);} }
    //получаем и заносим пароль в переменную, если пусто уничтожаем
	//unset() удаляет перечисленные переменные.
if (empty($login) or empty($password)) //если нет логи и пороля останавливаем скрипт и выводим ошибку
    {
    exit ("Вся поля обязательны для заполнения )!");
    }
    //удаляем все лишнее слеши
    $login = stripslashes($login);
    $login = htmlspecialchars($login);
$password = stripslashes($password);
    $password = htmlspecialchars($password);

    $login = trim($login); //trim удаление пробелов
    $password = trim($password); //trim удаление пробелов

    include ("../assets/data/db_connect.php");// подключение файла 
 error_reporting(1);
$result = mysqli_query("SELECT * FROM users WHERE login='$login'",$db); //mysql_query() посылает один запрос (посылка нескольких запросов не поддерживается) активной базе данных сервера, на который ссылается переданный дескриптор link_identifier .
    $myrow = mysqli_fetch_array($result);
    if (empty($myrow['password']))
    {
    //если такого логина в базе нет выводим ошибку
    exit ("Извините, такого логина или пароля у нас нет ). <br><a href='../index.php'>Главная страница</a>");
    }
    else {
    //если есть то проверяем пароль
    if ($myrow['password']==$password) {
    //если пароли совпадают запускаем сессию
    $_SESSION['login']=$myrow['login']; 
    $_SESSION['id']=$myrow['id']; //записываем в сессию
    echo "Вы вошли на сайт! <a href='index.php'>Главная страница</a>";
    }
 else {
    //если пароли не совпадают
    exit ("Извините, такого логина или пароля у нас нет ");
    }
    }
    ?>