<?php
    if (isset($_POST['login'])) { $login = $_POST['login']; if ($login == '') { unset($login);}} 
    if (isset($_POST['password'])) { $password=$_POST['password']; if ($password =='') { unset($password);}}
	//isset - Функция определяет, установлена ли переменная. Возвращает TRUE, если var существует, в противном случае возвращается FALSE
 if (empty($login) or empty($password)) 
    {
    exit ("Вся поля обязательны для заполнения )!");
    }
    $login = stripslashes($login); //stripslashes - режем слеши
    $login = htmlspecialchars($login); //htmlspecialchars - возврат отредактированной строки 
	$password = stripslashes($password);
    $password = htmlspecialchars($password);
    $login = trim($login); //trim удаление пробелов
    $password = trim($password);
    include ("../assets/data/db_connect.php");
    $result = mysqli_query("SELECT id FROM users WHERE login='$login'",$db); //mysql_query() посылает один запрос (посылка нескольких запросов не поддерживается) активной базе данных сервера, на который ссылается переданный дескриптор link_identifier .
    $myrow = mysqli_fetch_array($result); //mysql_fetch_array -- Обрабатывает ряд результата запроса, возвращая ассоциативный массив, численный массив или оба.
    if (!empty($myrow['id'])) {
    exit ("Извините, введённый вами логин уже зарегистрирован. Введите другой логин."); //Функция exit() заканчивает выполнение скрипта. Она печатает status непосредственно перед выходом. 
    } //проверка логина на совпадения.
	// сохранение логина если такой не зареган
    $result2 = mysqli_query ("INSERT INTO users (login,password) VALUES('$login','$password')");
    // Проверяем ошибки
    if ($result2=='TRUE')
    {
    echo "Вы успешно зарегистрированы! Теперь вы можете зайти на сайт. <a href='index.php'>Главная страница</a>";
    }
 else {
    echo "Ошибка! Вы не зарегистрированы.";
    }
    ?>