<li class="list-item">
  <h3 class="desc-title">
    <a href="/view?id=<?=$item['id'];?>"><?=$item['title'];?></a>
  </h3>
  <div class="desc-data">
    <span class="temp"><?=$item['temp'];?></span>
  </div>
</li>