<?php 
	$items_list = [
	[ "id" => 1, 
    "title" => "Понедельник",
    "temp" => 15 
    ],
    [ "id" => 2, 
    "title" => "Вторник",
    "temp" => 25,
    ],
    [ "id" => 3, 
    "title" => "Среда",
    "temp" => 7 
    ]
];
?>