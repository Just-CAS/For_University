	<div class="<?=$item['class'];?>">
		<a href="<?=$item['link'];?>">
			<img src="<?=$item['src'];?>" alt="" />
		</a>
    </div>