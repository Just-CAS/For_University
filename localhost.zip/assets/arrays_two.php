<?php
	$features = array( 
		array( "wDelay" => "100ms", 
               "icon" => "pencil",
                "title" => "Consectetur Risus",
				"text" => "Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit."),
        array( "wDelay" => "300ms", 
               "icon" => "camera-outline",
               "title" => "Ultricies Aenean",
				"text" => "Cras justo odio, dapibus ac facilisis in, egestas eget quam. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Donec ullamcorper nulla non metus auctor fringilla."),
        array( "wDelay" => "500ms", 
               "icon" => "bookmark",
               "title" => "Cras Sollicitudin",
				"text" => "Etiam porta sem malesuada magna mollis euismod. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Maecenas faucibus mollis interdum.")
    );
				
	$plang = array(
		"logo-sample-01.jpg", 
		"logo-sample-02.jpg", 
		"logo-sample-03.png", 
		"logo-sample-04.jpg", 
		"logo-sample-05.jpg", 
		"logo-sample-06.png"
	);
?>