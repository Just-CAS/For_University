<html>
    <head>
    <title>Регистрация</title>
    </head>
    <body>
    <h2>Регистрация</h2>
    <form action="admin.php" method="get">
<p>
    <label>Ссылка<br></label>
    <input name="mu_linkz" type="text" size="15" maxlength="15">
    </p>
<p>
    <label>Текст<br></label>
    <input name="mu_titlez" size="15" maxlength="15">
    </p>
<p>
    <input type="submit" name="submit" value="Поехали">
</p></form>
<!--
	<form action="admin.php" method="get">
	<input name="time" type="text" size="10">
	<input type="submit" value="Получить значение">
	</form>-->
    </body>
    </html>
	
	
	
	
	